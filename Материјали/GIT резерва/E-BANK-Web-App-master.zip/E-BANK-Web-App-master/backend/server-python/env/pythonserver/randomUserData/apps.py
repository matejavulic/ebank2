from django.apps import AppConfig


class RandomuserdataConfig(AppConfig):
    name = 'randomUserData'
